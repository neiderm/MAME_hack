//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dialog.rc
//
#define IDD_MIDASSETUPDLG               101
#define IDD_MIDASCUSTOMQUALITYDIALOG    102
#define IDC_VERYLOWQUALITY              1001
#define IDC_LOWQUALITY                  1002
#define IDC_MEDIUMQUALITY               1003
#define IDC_HIGHQUALITY                 1004
#define IDC_VERYHIGHQUALITY             1005
#define IDC_CUSTOMQUALITY               1006
#define IDC_STEREO                      1008
#define IDC_COMBO2                      1011
#define IDC_SOUNDCARD                   1011
#define IDC_SOUNDCARDTEXT               1013
#define IDC_BUFFERTEXT                  1014
#define IDC_BUFFEREDIT                  1015
#define IDC_MILLISECONDSTEXT            1016
#define IDC_DSBUFFEREDIT                1017
#define IDC_DSBUFFERTEXT                1018
#define IDC_MIXRATECOMBO                1019
#define IDC_DSMILLISECONDSTEXT          1019
#define IDC_MIXRATETEXT                 1020
#define IDC_MIXMODEGROUP                1021
#define IDC_MIXNORMAL                   1022
#define IDC_MIXINTERPOLATING            1023
#define IDC_ADVANCED                    1024
#define IDC_NEVERDSOUND                 1026
#define IDC_SOUNDQUALITY                -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
