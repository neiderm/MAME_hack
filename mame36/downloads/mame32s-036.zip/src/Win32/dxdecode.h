/* Copyright 1998 Invasion Games.  All Rights Reserved.  Do NOT distribute. */

/* dxdecode.h for client */

/* Main header file for dxdecode.cpp */

#ifndef _DXDECODE_H
#define _DXDECODE_H

extern const char * DirectXDecodeError(HRESULT errorval);

#endif _DXDECODE_H
